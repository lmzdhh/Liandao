//
// Created by wang on 10/20/18.
//

#ifndef KUNGFU_MDENGINEDAYBIT_H
#define KUNGFU_MDENGINEDAYBIT_H
#include <map>
#include <vector>
#include "CoinPairWhiteList.h"
#include "IMDEngine.h"
#include "PriceBook20Assembler.h"

struct lws_context;
struct lws;

WC_NAMESPACE_START
class MDEngineDaybit:public IMDEngine
{
public:
    static MDEngineDaybit*       m_instance;
public:
    MDEngineDaybit();
    virtual ~MDEngineDaybit();

public:
    void load(const json& ) override;
    void connect(long ) override;
    void login(long ) override;
    void logout() override;
    void release_api() override { KF_LOG_INFO(logger, "release_api"); }
    bool is_connected() const override { return m_connected; }
    bool is_logged_in() const override { return m_logged_in; }
    std::string name() const  override { return "MDEngineDaybit"; }

public:
    void onMessage(struct lws*,char* , size_t );
    void onClose(struct lws*);
    void onWrite(struct lws*);
    void reset();
protected:
    void parseRspSubscribe(const rapidjson::Document&);
    void parseSubscribeData(const rapidjson::Document&);
    void set_reader_thread() override;
	 void doTradeData(const rapidjson::Document&, const std::string&);

private:
    void genSubscribeString();
    std::string genTradeString(const std::string&);

private:
    void createConnection();
    void lwsEventLoop();
    void sendMessage(std::string&& );

private:
    bool                        m_connected = false;
    bool                        m_logged_in = false;
    ThreadPtr                   m_thread;
private:
    CoinPairWhiteList           m_whiteList;
    std::vector<std::string>    m_subcribeJsons;
    int                         m_subcribeIndex = 0;
    int64_t                     m_id = 0;
    int                         m_priceBookNum = 20;
private:
    struct lws_context*         m_lwsContext = nullptr;
    struct lws*                 m_lwsConnection = nullptr;
    std::string                 m_protocol;
    std::string                 m_ip;
    int                         m_port;
    std::string                 m_path;

};
DECLARE_PTR(MDEngineDaybit);
WC_NAMESPACE_END
#endif //KUNGFU_MDENGINEDAYBIT_H
