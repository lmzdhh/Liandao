//
// Created by xiaoning on 12/02/18.
//
#include "MDEngineDaybit.h"
#include <stringbuffer.h>
#include <writer.h>
#include <document.h>
#include <libwebsockets.h>
#include <algorithm>
#include <stdio.h>
#include "../../utils/common/Utils.h"
using rapidjson::Document;
using namespace rapidjson;
using namespace kungfu;
using namespace std;
#define  SCALE_OFFSET 1e8
WC_NAMESPACE_START
//lws event function
static int lwsEventCallback( struct lws *conn, enum lws_callback_reasons reason, void *user, void* data, size_t len );
static  struct lws_protocols  lwsProtocols [] {{"wss://", lwsEventCallback, 0, 65536,}, { NULL, NULL, 0, 0 }};

MDEngineDaybit* MDEngineDaybit::m_instance = nullptr;

MDEngineDaybit::MDEngineDaybit(): IMDEngine(SOURCE_HUOBI)
{
    logger = yijinjing::KfLog::getLogger("MdEngine.Daybit");
    KF_LOG_DEBUG(logger, "MDEngineDaybit construct");
}

MDEngineDaybit::~MDEngineDaybit()
{
    if (m_thread)
    {
        if(m_thread->joinable())
        {
            m_thread->join();
        }
    }
    KF_LOG_DEBUG(logger, "MDEngineDaybit deconstruct");
}

void MDEngineDaybit::set_reader_thread()
{
    IMDEngine::set_reader_thread();
    m_thread = ThreadPtr(new std::thread(boost::bind(&MDEngineDaybit::lwsEventLoop, this)));
}

void MDEngineDaybit::load(const json& config)
{
    KF_LOG_INFO(logger, "load config start");
    try
    {
        m_priceBookNum = config["book_depth_count"].get<int>();
        m_protocol = config["protocol"].get<std::string>();
        m_ip = config["ip"].get<std::string>();
        m_port = config["port"].get<int>();
        m_path = config["path"].get<std::string>();
        m_whiteList.ReadWhiteLists(config, "whiteLists");
        m_whiteList.Debug_print();
        genSubscribeString();
    }
    catch (const std::exception& e)
    {
        KF_LOG_INFO(logger, "load config exception,"<<e.what());
    }
    KF_LOG_INFO(logger, "load config end");
}

void MDEngineDaybit::genSubscribeString()
{
    auto& symbol_map = m_whiteList.GetKeyIsStrategyCoinpairWhiteList();
    for(const auto& var : symbol_map)
    {        
        m_subcribeJsons.push_back(genTradeString(var.second));
    }
    if(m_subcribeJsons.empty())
    {
        KF_LOG_INFO(logger, "genSubscribeString failed, {error:has no white list}");
        exit(0);
    }
}

std::string MDEngineDaybit::genTradeString(const std::string& symbol)
{
    rapidjson::StringBuffer buffer;
    rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);
    writer.StartObject();
    writer.Key("sub");
    std::string sub_value("market.");
    sub_value += symbol+".trade.detail";
    writer.String(sub_value.c_str());
    writer.Key("id");
    writer.String(std::to_string(m_id++).c_str());
    writer.EndObject();
    return buffer.GetString();
}

void MDEngineDaybit::connect(long)
{
    KF_LOG_INFO(logger, "connect");
    m_connected = true;
}

void MDEngineDaybit::login(long)
{
    KF_LOG_DEBUG(logger, "create context start");
    m_instance = this;
    struct lws_context_creation_info creation_info;
    memset(&creation_info, 0x00, sizeof(creation_info));
    creation_info.port = CONTEXT_PORT_NO_LISTEN;
    creation_info.protocols = lwsProtocols;
    creation_info.gid = -1;
    creation_info.uid = -1;
    creation_info.options |= LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT;
    creation_info.max_http_header_pool = 1024;
    creation_info.fd_limit_per_thread = 1024;
    m_lwsContext = lws_create_context( &creation_info );
    if (!m_lwsContext)
    {
        KF_LOG_ERROR(logger, "create context error");
        return;
    }
    KF_LOG_INFO(logger, "create context success");
    createConnection();
}

void MDEngineDaybit::createConnection()
{
    KF_LOG_DEBUG(logger, "create connect start");
    struct lws_client_connect_info conn_info = { 0 };
    //parse uri: wss://api.daybit.com/v1/user_api_socket/websocket/
    conn_info.context 	= m_lwsContext;
    conn_info.address = "api.daybit.com"
    conn_info.path 	= "/v1/user_api_socket/websocket/";
    conn_info.port = 443;
    conn_info.protocol = lwsProtocols[0].name;
    conn_info.host 	= conn_info.address;
    conn_info.origin = conn_info.address;
    conn_info.ssl_connection = LCCSCF_USE_SSL | LCCSCF_ALLOW_SELFSIGNED | LCCSCF_SKIP_SERVER_CERT_HOSTNAME_CHECK;
    m_lwsConnection = lws_client_connect_via_info(&conn_info);
    if(!m_lwsConnection)
    {
        KF_LOG_INFO(logger, "create connect error");
        return ;
    }
    KF_LOG_INFO(logger, "connect to "<< conn_info.protocol<< conn_info.address<< ":"<< conn_info.port<< conn_info.path <<" success");
    m_logged_in = true;
}

void MDEngineDaybit::logout()
{
    lws_context_destroy(m_lwsContext);
    m_logged_in = false;
    KF_LOG_INFO(logger, "logout");
}

void MDEngineDaybit::lwsEventLoop()
{
    while(isRunning)
    {
        lws_service(m_lwsContext, 500);
    }
}

void MDEngineDaybit::sendMessage(std::string&& msg)
{
    msg.insert(msg.begin(),  LWS_PRE, 0x00);
    lws_write(m_lwsConnection, (uint8_t*)(msg.data() + LWS_PRE), msg.size() - LWS_PRE, LWS_WRITE_TEXT);
}

void MDEngineDaybit::onMessage(struct lws* conn, char* data, size_t len)
{
    KF_LOG_DEBUG(logger, "received data from daybit start");
    try
    {
        if(!isRunning)
        {
            return;
        }
        Document json;
        auto dataJson = LDUtils::gzip_decompress(std::string(data,len));
        json.Parse(dataJson.c_str());
        KF_LOG_DEBUG(logger, "received data from daybit,{msg:"<< dataJson<< "}");
        if(json.HasParseError())
        {
            KF_LOG_ERROR(logger, "received data from daybit failed,json parse error");
            return;
        }
        else if(json.HasMember("id"))
        {
            //rsp sub;
            parseRspSubscribe(json);
        }
        else if(json.HasMember("ch"))
        {
            //rtn sub
            parseSubscribeData(json);
        }
    }
    catch(const std::exception& e)
    {
        KF_LOG_ERROR(logger, "received data from daybit exception,{error:" << e.what() << "}");
    }
    catch(...)
    {
        KF_LOG_ERROR(logger, "received data from daybit system exception");
    }
    KF_LOG_DEBUG(logger, "received data from daybit end");
}

void MDEngineDaybit::onClose(struct lws* conn)
{
    if(isRunning)
    {
        reset();
        login(0);
    }
    if(!m_logged_in)
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(2000));
    }

}
void MDEngineDaybit::reset()
{
    m_subcribeIndex = 0;
    m_logged_in     = false;
}

void MDEngineDaybit::onWrite(struct lws* conn)
{
    if(!isRunning)
    {
        return;
    }
    KF_LOG_DEBUG(logger, "subcribe start");
    if (m_subcribeJsons.empty() || m_subcribeIndex == -1)
    {
        KF_LOG_DEBUG(logger, "subcribe ignore");
        return;
    }
    auto symbol = m_subcribeJsons[m_subcribeIndex++];
    KF_LOG_DEBUG(logger, "req subcribe " << symbol);
    sendMessage(std::move(symbol));
    if(m_subcribeIndex >= m_subcribeJsons.size())
    {
        m_subcribeIndex = -1;
        KF_LOG_DEBUG(logger, "subcribe end");
        return;
    }
    if(isRunning)
    {
        lws_callback_on_writable(conn);
    }
    KF_LOG_DEBUG(logger, "subcribe continue");
}


/*
 * right subcribe rsp
{
"id": "id1",
"status": "ok",
"subbed": "market.btcusdt.kline.1min",
"ts": 1489474081631
}
*/

/*
 * error subcribe rsp
{
"id": "id2",
"status": "error",
"err-code": "bad-request",
"err-msg": "invalid topic market.invalidsymbol.kline.1min",
"ts": 1494301904959
}
 */
 void MDEngineDaybit::parseRspSubscribe(const rapidjson::Document& json)
 {
     if (0 == strcmp(json["status"].GetString(), "error"))
     {
         //ignore failed subcribe
         KF_LOG_INFO(logger, "subscribe sysmbol error");
         return;
     }
     KF_LOG_DEBUG(logger, "subscribe {sysmbol:"<< json["subbed"].GetString()<<"}");
 }

 void MDEngineDaybit::parseSubscribeData(const rapidjson::Document& json)
 {
     KF_LOG_DEBUG(logger, "parseSubscribeData start");
     auto ch = LDUtils::split(json["ch"].GetString(), ".");
     if(ch.size() != 4)
     {
         KF_LOG_INFO(logger, "parseSubscribeData [ch] split error");
        return;
     }
     auto instrument = m_whiteList.GetKeyByValue(ch[1]);
     if(instrument.empty())
     {
         KF_LOG_DEBUG(logger, "parseSubscribeData whiteList has no this {symbol:"<<instrument<<"}");
         return;
     }
     if (ch[2] == "trade")
     {
         doTradeData(json, instrument);
         return;
     }
 }


 void MDEngineDaybit::doTradeData(const rapidjson::Document& json, const std::string& instrument)
 {
     try
     {
         KF_LOG_DEBUG(logger, "doTradeData start");
         if (!json.HasMember("tick"))
         {
             return;
         }
         auto& tick = json["tick"];
         if (!tick.HasMember("data"))
         {
             return;
         }
         auto& data = tick["data"];
         if(data.Empty())
         {
             return;
         }
         LFL2TradeField trade{0};
         strncpy(trade.ExchangeID, "daybit", std::min((int)sizeof(trade.ExchangeID)-1, 5));
         strncpy(trade.InstrumentID, instrument.c_str(),std::min(sizeof(trade.InstrumentID)-1, instrument.size()));
         auto& first_data = data[0];
         trade.Volume =  std::round(first_data["amount"].GetDouble() * SCALE_OFFSET);
         trade.Price  =  std::round(first_data["price"].GetDouble() * SCALE_OFFSET);
         std::string side = first_data["direction"].GetString();
         trade.OrderBSFlag[0] = side == "buy" ? 'B' : 'S';
         on_trade(&trade);
     }
     catch (const std::exception& e)
     {
         KF_LOG_INFO(logger, "doTradeData,{error:"<< e.what()<<"}");
     }
     KF_LOG_DEBUG(logger, "doTradeData end");
 }

 int lwsEventCallback( struct lws *conn, enum lws_callback_reasons reason, void *, void *data , size_t len )
{
    switch( reason )
    {
        case LWS_CALLBACK_CLIENT_ESTABLISHED:
        {
            lws_callback_on_writable( conn );
            break;
        }
        case LWS_CALLBACK_CLIENT_RECEIVE:
        {
            if(MDEngineDaybit::m_instance)
            {
                MDEngineDaybit::m_instance->onMessage(conn, (char*)data, len);
            }
            break;
        }
        case LWS_CALLBACK_CLIENT_WRITEABLE:
        {
            if(MDEngineDaybit::m_instance)
            {
                MDEngineDaybit::m_instance->onWrite(conn);
            }
            break;
        }
        case LWS_CALLBACK_WSI_DESTROY:
        case LWS_CALLBACK_CLOSED:
        case LWS_CALLBACK_CLIENT_CONNECTION_ERROR:
        {
            if(MDEngineDaybit::m_instance)
            {
                MDEngineDaybit::m_instance->onClose(conn);
            }
            break;
        }
        default:
            std::cout<< "callback #"<<(int)reason<<std::endl;
            break;
    }
    return 0;
}

BOOST_PYTHON_MODULE(libdaybitmd)
{
    using namespace boost::python;
    class_<MDEngineDaybit, boost::shared_ptr<MDEngineDaybit> >("Engine")
            .def(init<>())
            .def("init", &MDEngineDaybit::initialize)
            .def("start", &MDEngineDaybit::start)
            .def("stop", &MDEngineDaybit::stop)
            .def("logout", &MDEngineDaybit::logout)
            .def("wait_for_stop", &MDEngineDaybit::wait_for_stop);
}

WC_NAMESPACE_END